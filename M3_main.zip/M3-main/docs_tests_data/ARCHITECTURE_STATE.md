# ARCHITECTURE_STATE

- Generated: 2026-02-26T17:59:50+00:00
- Commit: `UNKNOWN`
- Branch: `UNKNOWN`
- Repro seed/config: deterministic (no randomness used in generator)

## Module graph / dependency overview

### Key modules

### Internal dependency edges

- UNKNOWN

## Entry points

- UNKNOWN

## Env toggles used in run paths

- UNKNOWN

## Extended Docs

- `docs_tests_data/VISUAL_MAP.md`
- `docs_tests_data/VISUAL_MAP.svg`
- `docs_tests_data/CLASS_CATALOG.md`
- `docs_tests_data/CHANGE_REPORT.md`
